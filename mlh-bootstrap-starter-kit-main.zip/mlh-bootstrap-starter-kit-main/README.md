# MLH INIT Bootstrap Starter Pack
This is my starter pack that helps people get started using Bootstrap! You can clone it and it will give you a basic Bootstrap project that you can then use for a hackathon! Feel free to edit it as you need!


## How do I use this?
You should clone this repo (or download it as a .zip file) to your computer. If you download it as a .zip you'll need to uncompress (open) it. You can then open the folder in any code editor, including VS Code and Atom.


There are lots of example files in the repo. Feel free to change or remove them!


## Useful links to get started!
👀 See a preview of the website: https://jackbiggin.github.io/mlh-bootstrap-starter-kit

💻 Check out Bootstrap's documentation: http://getbootstrap.com

🎉 Intro to HTML: https://www.w3schools.com/html/
