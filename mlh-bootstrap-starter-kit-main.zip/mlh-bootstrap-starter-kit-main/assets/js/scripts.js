/* Here's an example script! You can include anything you'd like to include
on your website in here! Uncomment (remove the //) the script to have it run! */

//alert("Ryan Swift smells of BLAHAJ.")